import gi, time, json, pexpect, paramiko, pytz #Librerias a utilizar en el programa

from datetime import datetime #Libreria para las fechas y horas.

gi.require_version("Gtk","3.0") #Versión requerida para el uso de la GUI y evitar problemas con la conexión al conectarlo a la interfaz gráfica, debido a los elementos hacen uso de esa libreria.

from gi.repository import Gtk # Importar la libreria que fue requerida con su version.

concatenate = ""		#Concatenara los hostname y direcciones IP ingresados, para que se puedan mostrar en el programa.
dispositivos = {}		#Todos los hostname y direcciones IP que sean ingresados se almacenan en un diccionario.
resultado = ""			#String dedicado al resultado obtenido en las consultas realizadas
option_selected_command = None		#Se almacena el numero de opcion seleccionado por el usuario de la consulta a realizar.
option_selected_mode = None				#Almacena el numero de opcion respecto al protocolo a usar.
send_comm = ""	#Almacena el comando de la consulta a realizar
type_route = {"C":"Conectado","S":"Estatico", "R":"RIP", "B":"BGP","D":"EIGRP", "EX":"EIGRP externo", "O":"OSFP", "IA":"OSPF area interna","N1":"OSPF NSSA externo tipo 1","N2":"OSPF NSSA externo tipo 2","E1":"OSPF externo tipo 1","E2":"OSPF externo tipo 2","L1":"IS-IS nivel 1","L2":"IS-IS nivel 2","*":"candidate default", "U":"Router estatico por usuario","P":"Ruta estatica descargada periodicamente"} #Diccionario con los tipos de enrutamiento, las llaves llevan su abreviación y los valores el significado de la abreviatura del enrutamiento.

def routeInNetwork(result_route):	#Función dedicado a convertir las abreviaturas en su respectivo significado.
	route_used = []									#Lista de los enrutamientos hallados, que devuelve su significado.
	for enrut in type_route.keys():	#Iteración que recorre el diccionario.
		if enrut in result_route:			#Si la abreviatura del enrutamiento está dentro de los enrutamientos hallados, almacena el significado de la abreviatura en la lista.
			route_used.append(type_route[enrut])
	
	return route_used #Devuelve la lista con su respectivo resultado.

def selectionCombBoxMode(combo):	#Función dedicado al protocolo seleccionado.
	global option_selected_mode	#Se manda a llamar la variable indicando que el valor cambiará de manera global.
	option_selected_mode = combo.get_active()	#Obtiene el valor de la opción seleccionada del tipo de protocolo.
	print(option_selected_mode)
	
def selectionCombBoxCommand(combo):	#La función obtiene el comando seleccionado y aparte almacena el comando de la instrucción correspondiente.
	
	global option_selected_command	#Manda a llamar las variables indicando que el valor obtenido almacenado también cambiará fuera de la función.
	global send_comm
	
	option_selected_command = combo.get_active()	#Almacena la opcion seleccionada respecto a la instrucción seleccionada.
	print(option_selected_command)
	
	#En el condicional, dependiendo de la opcion seleccionada sobre la instrucción a realizar, almacena el comando que será introducido dentro del protocolo Telnet o SSH.
	
	if option_selected_command == 0:	#Opción correspondiente a mostras las interfaces.
		send_comm = "show ip interface brief" + " | exclude unas\n"
	elif option_selected_command == 1:	#Opción correspondiente a las versiones de los routers.
		send_comm = "show version" + " | i V\n"	
	elif option_selected_command == 2:	#Opción que corresponde al SSH en los dispositivos y si está habilitado.
		send_comm = "show ip ssh" + " \n"
	elif option_selected_command == 3 or option_selected_command == 4:
		send_comm = "show ip route" + " \n"	# Opción que corresponde al enrutamiento.
	elif option_selected_command == 5:		#Opcion relacionada al comando para mostrar las configuraciones realizadas en el dispositivo.
		send_comm = "show startup-config" + " \n"
	elif option_selected_command == 6:	#Mostrar las direcciones relacionados con el router.
		send_comm = "show arp" + " \n"
	elif option_selected_command == 7:	#Opcion para mostrar las traducciones NAT de los dispositivos.
		send_comm = "show ip nat translations" + " \n"
	elif option_selected_command == 8:	#Opción para mostras las listas de acceso.
		send_comm = "show ip access-list" + " \n"
	
	

def seleccionarArchivo(filechooserbutton):	#Función que corresponde a la selección y almacenamiento del contenido del archivo JSON.

	name_file = filechooserbutton.get_filename()#Despliega una ventana para seleccionar y almacenar el archivo.
	
	with open(name_file,'r') as f:#Realizaz la lectura del archivo JSON.
		devices = json.load(f)	#Carga el contenido del archivo JSON
		print(devices)
	
	global dispositivos	#Se declara como variable global para que almacene los dispositivos y actualice su contenido.
	dispositivos.update(devices) #Actualiza el contenido con los dispositivos del contenido del archivo.
	
	list_keys = list(devices.keys())	#Guarda las llaves correspondientes al hostname.
	
	global concatenate	#Se manda a llamar la variable que almacena los dispositivos disponibles y los actualiza en el cuadro de dispositivos.
	
	for i in range(len(list_keys)):#	Iteración para almacenar el contenido de los dispositivos y mostrarlos más adelante en el cuadro.
		concatenate = concatenate + list_keys[i] + " " + devices[list_keys[i]]["ip"] + "\n"
	
	
	#print(concatenate)
	
	text_buffer = square_text.get_buffer()#Actualiza el contenido del cuadro en blanco con lo que contiene concatenate.
	scrolled_window = Gtk.ScrolledWindow()
	text_buffer.set_text(concatenate)	
	
	print(dispositivos)


def performConsult(button):	#Función principal para la realización de las consultas.

	global dispositivos	#Variables globales que cambian su valor durante el proceso de la función.
	global send_comm		
	global option_selected_mode	
	global option_selected_command		
	global resultado								
	
	username = 'cisco'	#Para el proyecto solo se utilizará el mismo usuario y contraseña para la topologia en ambos protocolos.
	password = 'cisco'
	
	resultado = ""			#Cada que se llame la función para realizar una consulta, se dejará vacio la variable resultado.
	result_routes = []	#Se crean las lista para almacenar los resultados de los enrutamientos en la red, si es que la opción escogida fue el 4.
	
	if option_selected_mode == 0:#En el if, está el caso de que si se escoge el protocolo Telnet.
		
		
		for dispositivo in dispositivos.keys():	#Se realiza la iteración de los dispositivos almacenados.
			device_prompt = dispositivos[dispositivo]['prompt']	#Se almacena el prompt correspondiente.
			child = pexpect.spawn('telnet ' + dispositivos[dispositivo]['ip'])	#Se envian como entrada por medio de spawn.
				
			child.expect('Username:')	#Se espera a que se devuelva una cadena.
			child.sendline(username)	#Escribe la cadena en la aplicación.
			child.expect('Password:')	#Se espera a que se devuelva una cadena.
			child.sendline(password)	#Escribe la cadena en la aplicación.
			child.expect(device_prompt)	#Se espera a que se devuelva una cadena. Se envia el prompt.
			child.sendline(send_comm)	#Se envia el comando.
			child.expect(device_prompt)	#Se espera la devolución de la respuesta con el prompt.
			
				
			if option_selected_command == 4:	#En caso de que la opción de la instrucción tenga el valor de 4 se ingresa al if.
					
				salida_decode = child.before.decode('UTF-8')	#Se obtiene el resultado decodificado de bytes a string
				salida_decode = salida_decode[salida_decode.index("Gateway"):] #Se obtiene la cadena que va del Gateway en adelante.
					
				result_routes = result_routes + routeInNetwork(salida_decode)	#Se realiza la concatenación de las listas de la cadena de los enrutamientos más los que se obtenga en la función routeInNetwork.
					
			else:	#En caso de que la opcion no tenga el valor de 4, se engresa al else.
					
				resultado = resultado + child.before.decode('UTF-8') + "\n"	#Se obtiene el resultado convertido de bytes a string.
				
				
			child.sendline('exit')#Se el comando para indicar la salida.
			
		if option_selected_command == 4:#Al salir de la iteración, dependiendo de la opción del comando, se realizará el guardado en la variable resultado. En caso de que el valor de la opcion sea 4, se ingreda al if.
				
			result_routes = list(dict.fromkeys(result_routes))	#Se eliminan los enrutamientos que aparecen repetidos.
				
			resultado = "Enrutamiento configurado en la red: \n"	#Se crea el texto que se almacenara en el resultado
				
			for element in result_routes:	#La iteración recorrerá la lista de los enrutamientos identificados.
				resultado = resultado + element + "\n"	#Se concatena el texto con los elementos de la lista.
					
			text_buffer = etiqueta_resultado.get_buffer()	#Se muestra en el cuadro de texto los resultados.
			scrolled_window = Gtk.ScrolledWindow()
			#scrolled_window.add("Si se pudo")
			text_buffer.set_text(resultado)
				
		else:#Se realizaz una impresión diferente para los valores diferentes a 4.
				
			text_buffer = etiqueta_resultado.get_buffer()#Se imprime en el cuadro de texto el resultado obtenido.
			scrolled_window = Gtk.ScrolledWindow()
			#scrolled_window.add("Si se pudo")
			text_buffer.set_text(resultado)
	
	elif option_selected_mode == 1:	#Si el valor de la opción del protocolo es 1, se realiza el protocolo SSH.
		
		for dispositivo in dispositivos.keys():#Se recorre el contenido de los dispositivos.
		
			conexion = paramiko.SSHClient()	#Se crea una sesión del cliente.

			conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy()) #Se configura la politica a usar cuando se conecte a los routers.

			conexion.connect(dispositivos[dispositivo]['ip'],username = username,password=password,look_for_keys=False,allow_agent=False)	#Se conecta al servidor.

			nueva_conexion = conexion.invoke_shell()#inicia una sesión shell.

			salida = nueva_conexion.recv(5000) #Se especifica el numero de bytes para la salida obtenida.
			

			nueva_conexion.send(send_comm)	#Se manda el comando.

			time.sleep(3)#Se da un tiempo de espera de 3 segundos.
			
			if option_selected_command == 4:	#Se ingresa al if si el valor de la opción de la instrucción seleccionada es igual a 4.
				salida = nueva_conexion.recv(5000)		#Se especifica el numero de bytes para obtener el resultado.
				salida_decode = salida.decode('UTF-8')	#Se obtiene la salida de bytes a string.
				
				salida_decode = salida_decode[salida_decode.index("Gateway"):] #Se obtiene la cadena que va del Gateway en adelante.
				
				result_routes = result_routes + routeInNetwork(salida_decode)	#Se realiza la concatenación de las listas.
				
				#resultado = resultado + salida.decode('UTF-8') + "\n"
			else:#En caso de que el valor no sea igual a 4, se ingresa al else.
			
				salida = nueva_conexion.recv(5000)	#Se recibe la salida con el numero de bytes especificaado.
				
				resultado = resultado + salida.decode('UTF-8') + "\n"	#Se concatena el string resultado con la salida convertida a string.
			
			#print(salida.decode('UTF-8'))

			nueva_conexion.close()	#Se cierra la conexion.
		
		if option_selected_command == 4: #Al concluir la iteración, si el valor de la opción del comando es igual a 4, se ingresa al if.
			
			result_routes = list(dict.fromkeys(result_routes))	#Se elimina los elementos repetidos en la lista.
			
			resultado = "Enrutamiento configurado en la red: \n"	#Se almacena la cadena a la variable resultado.
			
			for element in result_routes:			#Se recorre la lista.
				resultado = resultado + element + "\n"	#Se concatena el resultado con los elementos de la lista de enrutamiento.
				
			text_buffer = etiqueta_resultado.get_buffer()	#Se muestra el resultado en el cuadro blanco.
			scrolled_window = Gtk.ScrolledWindow()
			#scrolled_window.add("Si se pudo")
			text_buffer.set_text(resultado)
			
		else:#Si se tiene otro valor aalmacenado, entra al else.
			
			text_buffer = etiqueta_resultado.get_buffer()#Se muestra el resultado en el cuadro blanco.
			scrolled_window = Gtk.ScrolledWindow()
			#scrolled_window.add("Si se pudo")
			text_buffer.set_text(resultado)
		

def ingresar_texto(button):	##Función correspondiente al ingreso del hostname y la dirección IP.
	
	text_buffer = square_text.get_buffer()	#Se crea el buffer del elemento del cuadro para que se puede poner el contenido en el cuadro.
	scrolled_window = Gtk.ScrolledWindow()
	#scrolled_window.add("Si se pudo")
	
	global concatenate	#Se manda a llamar las variables de manera global
	global dispositivos	#para que se puedan actualizar el valor de las variables.
	
	in_hostname = entrada_operando_1.get_text()	#Se obtiene el hostname ingresado.
	in_ip = entrada_operando_2.get_text()	#Se obtiene la dirección IP ingresado.
	
	
	concatenate = concatenate +  in_hostname + " " + in_ip + "\n"	#Se concatena los datos obtenidos con la variable concatenate, el cual tiene almacenado los hostname y las direcciones IP que se muestran en el cuadro blanco del programa.
	
	hostname_prompt = in_hostname + "#"	#Se crea el prompt.
	
	dispositivos[in_hostname] = {"prompt":hostname_prompt,"ip":in_ip}	#Se almacena, en el diccionario de dispositivos, la dirección IP, el hostname y el prompt.
	
	print(dispositivos)
	
	text_buffer.set_text(concatenate)	#Se muestra en pantalla los dispositivos actualizados.

def emptyData(button):	#Función para vaciar el contenido dentro de el diccionario dispositivos.
	
	text_buffer = square_text.get_buffer()	#Se crea el buffer del elemento del cuadro para que se puede poner el contenido en el cuadro.
	scrolled_window = Gtk.ScrolledWindow()
	#scrolled_window.add("Si se pudo")

	global dispositivos#Se manda a llamar las variables de manera global
	global concatenate
	
	concatenate = ""		#La variable concatenate se le declara sin contenido.
	dispositivos.clear()	#Se deja vacio el contenido del diccionario dispositivos.
	
	text_buffer.set_text(concatenate)#Se muestra en pantalla los dispositivos actualizados.


def saveResults(button):	# Función para guardar en un archivo los resultados.

	global resultado	#Se declara la variable como global.
	datetime_Mex = datetime.now(pytz.timezone('Mexico/General'))	#Se obtiene el tiempo y fecha de la zona de México.
	format_date = datetime_Mex.strftime('%d%m%Y_%H%M%S')	#Se obtiene el formato de la fecha y horas.
	title_file = "Resultados_" + format_date + ".txt"	#Se crea el titulo del archivo junto la fecha, hora y la extensión.
	
	with open(title_file, 'wb') as f:	#Se guardan los resultados en el archivo.
		f.write(resultado.encode('UTF-8'))	#Antes de guardar los resultados, se convierte de string a bytes el contenido.

builder = Gtk.Builder()				#Se crea el objeto GTK.
builder.add_from_file("gui_prueba.glade")	#Se añade el archivo de la interfaz gráfica.

handlers = {"cerrar_ventana":Gtk.main_quit, "click_boton1":performConsult,"click_boton_2":ingresar_texto, "select_file":seleccionarArchivo, "opt_select":selectionCombBoxCommand, "opt_mode":selectionCombBoxMode,
"click_vaciar":emptyData,
"click_guardar":saveResults}	#Se almacenan los eventos correspondientes a los elementos de la interfaz gráfica. Cada evento está relacionado a una de las funciones antes vistas.


builder.connect_signals(handlers)	#Se conecta con los eventos y funciones.

etiqueta_resultado = builder.get_object("cuadro_texto")	#Se almacena el objeto de los cuadros de texto.
square_text = builder.get_object("cuadro_texto_2")

entrada_operando_1 = builder.get_object("in_1")	#Se almacenan los objetos correspondiente al cuadro donde se llena los datos, que son el hostname y la dirección ip.
entrada_operando_2 = builder.get_object("in_2")

window = builder.get_object("ventana")	#Se obtiene el objeto correspondiente a la ventana del programa.

window.show_all()	#Se muestra la ventana.

Gtk.main()	#Se activa el despliegue principal de la ventana del progra.a
